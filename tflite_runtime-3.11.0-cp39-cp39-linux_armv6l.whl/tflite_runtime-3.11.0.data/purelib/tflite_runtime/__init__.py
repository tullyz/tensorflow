__version__ = '3.11.0'
__git_version__ = '$(git -C ~/tensorflow_src describe)'

